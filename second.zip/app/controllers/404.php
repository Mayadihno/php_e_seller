<?php

echo "Page not found\n";
