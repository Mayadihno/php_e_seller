<?php require './app/views/inc/header.inc.php'; ?>
        <?php echo $contents; ?>
 <?php require './app/views/inc/footer.inc.php'; ?>