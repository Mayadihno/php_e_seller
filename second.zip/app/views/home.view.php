<?php

use Auth\Session;

$session = new Session();

include __DIR__ . '/../views/home/banner.inc.php';
include __DIR__ . '/../views/home/categories.inc.php';
include __DIR__ . '/../views/home/latest.inc.php';
include __DIR__ . '/../views/home/blog.inc.php';
