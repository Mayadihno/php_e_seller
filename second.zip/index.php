<?php
require './app/core/init.php';
